import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-room-componente',
  templateUrl: './room-componente.component.html',
  styleUrls: ['./room-componente.component.css']
})
export class RoomComponenteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
